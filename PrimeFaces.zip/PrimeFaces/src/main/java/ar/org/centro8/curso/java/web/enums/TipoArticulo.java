package ar.org.centro8.curso.java.web.enums;

public enum TipoArticulo {
	PRENDA,
	JUGUETE,
	ALIMENTO,
	SNACK,
	ACCESORIO,
	CORREAS,
	MEDICAMENTO

}
