package ar.org.centro8.curso.java.web.enums;

public enum TipoDocumento {
    DNI,
    LC,
    LE,
    CI,
    PASS
}
